package br.com.treinaweb.java.basico;

public class Principal {

	public static void main(String[] args) {

		String nomePessoa = "Robson";
		int idadePessoa = 20;
		double pesoPessoa = 80.0;

		System.out.println("Hello World");
		System.out.println("Ol�, " + nomePessoa);
		System.out.println("Voc� tem " + idadePessoa + " anos");
		System.out.println("Voc� tem " + pesoPessoa + " peso");
		
		
	}

}
